// Definition of pysamerr
#include "stdio.h"
FILE * pysamerr = NULL;


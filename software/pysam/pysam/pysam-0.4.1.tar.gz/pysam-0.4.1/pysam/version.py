# pysam versioning information

__version__ = "0.4.1"

__samtools_version__ = "0.1.12a"

__tabix_version__ = "0.2.3"

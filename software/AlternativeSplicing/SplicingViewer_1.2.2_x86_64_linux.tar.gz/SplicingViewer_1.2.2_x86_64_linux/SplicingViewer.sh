cd "$(dirname "$0")"
java -Xmx1000m -XX:MaxPermSize=256m -jar SplicingViewer.jar


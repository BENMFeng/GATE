Require:
java 1.6 or higher